from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import openai
from langchain_openai.embeddings import OpenAIEmbeddings
from langchain_postgres import PGVector

# Database and API configurations
DATABASE_URL = "postgresql://goutham:pass@localhost:5432/_langchain1"
openai_api_key = "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"

# Initialize SQLAlchemy engine and session
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()

# Initialize OpenAI Embeddings and PGVector
embeddings = OpenAIEmbeddings(api_key=openai_api_key, request_timeout=30)
vectorstore = PGVector(
    connection=engine,
    embeddings=embeddings,
    collection_name="bail_cases",
    embedding_length=1536,
    use_jsonb=False  # Switch to vector storage
)

# Initialize OpenAI client
openai.api_key = openai_api_key
client = openai

def query_section(ipc_section):
    """
    Queries the bail_cases database using vectors and enriches with OpenAI.
    
    Args:
        ipc_section (str): The IPC section in the format IPC_XXX.

    Returns:
        dict: Response details.
    """
    try:
        # Retrieve embedding for the IPC section
        ipc_embedding = embeddings.embed_query(ipc_section)

        # Query using the embedding
        results = vectorstore.similarity_search(
            query_vector=ipc_embedding,
            top_k=1  # Retrieve the most relevant result
        )

        if results:
            # Fetch necessary fields
            result = results[0].metadata
            section = result.get("section")
            offense_type = result.get("offense_type")
            bail_status = "Yes" if result.get("bailable") else "No"
            bail_eligibility = result.get("bail_eligibility")

            # Use OpenAI for punishment, description, and process to follow
            prompt = f"""
            Section: {section}
            Offense Type: {offense_type}
            Bail Status: {bail_status} (Eligibility: {bail_eligibility})
            
            Provide:
            - Punishment
            - Description
            - Process to Follow
            """
            openai_response = client.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a legal expert."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
            )
            ai_content = openai_response.choices[0].message.content

            return {
                "section": section,
                "offense_type": offense_type,
                "bail_status": bail_status,
                "bail_eligibility": bail_eligibility,
                "details": ai_content
            }
        else:
            # No Database Result
            prompt = f"""
            Provide detailed information for IPC section: {ipc_section}.
            
            Include:
            - Offense Type
            - Bail Status
            - Punishment
            - Description
            - Process to Follow
            """
            openai_response = client.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a legal expert."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500
            )
            ai_content = openai_response.choices[0].message.content
            return {"details": ai_content}

    except Exception as e:
        return {"error": str(e)}
