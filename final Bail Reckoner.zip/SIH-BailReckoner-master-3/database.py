from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, Boolean, Date
from sqlalchemy.orm import sessionmaker
import pandas as pd
from sqlalchemy.sql import text
from langchain_openai.embeddings import OpenAIEmbeddings
from langchain_postgres import PGVector

# Database and API configurations
DATABASE_URL = "postgresql://goutham:pass@localhost:5432/_langchain1"
openai_api_key = "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"

# Initialize SQLAlchemy
engine = create_engine(DATABASE_URL)
metadata = MetaData()

# Define Table Schema with vector embeddings
bail_cases = Table(
    "bail_cases", metadata,
    Column("id", Integer, primary_key=True),
    Column("prisoner_name", String),
    Column("case_number", Integer, unique=True),
    Column("charges", String),
    Column("arrest_date", Date),
    Column("offense_type", String),
    Column("served_duration", Integer),
    Column("risk_evaluation", String),
    Column("bailable", Boolean),
    Column("bail_eligibility", String),
    Column("section", String),
    Column("offense", String),
    Column("punishment", String)
)

# Create the table if it doesn't exist
metadata.create_all(engine)

Session = sessionmaker(bind=engine)
session = Session()

# Initialize OpenAI Embeddings
embeddings = OpenAIEmbeddings(api_key=openai_api_key, request_timeout=30)

# Initialize PGVector for vector storage and retrieval
vectorstore = PGVector(
    connection=engine,
    embeddings=embeddings,
    collection_name="bail_cases",
    embedding_length=1536,
    use_jsonb=False  # Use vector storage
)

# Function to load and clean CSV data
def clean_and_load_csv(file_path):
    try:
        data = pd.read_csv(
            file_path,
            delimiter=";",
            skip_blank_lines=True,
            on_bad_lines="skip",
            encoding="utf-8"
        )

        column_rename_map = {
            "caseNumber": "case_number",
            "sectionName": "section",
            "offenseType": "offense_type",
            "Served Duration": "served_duration",
            "riskEvaluation": "risk_evaluation",
            "bailable": "bailable",
            "bailEligibility": "bail_eligibility",
        }
        data.rename(columns=column_rename_map, inplace=True)

        required_columns = [
            "case_number", "section", "offense_type",
            "served_duration", "risk_evaluation", "bailable", "bail_eligibility"
        ]
        data = data[[col for col in required_columns if col in data.columns]]

        data.fillna("Not Specified", inplace=True)

        # Ensure case_number is integer
        if "case_number" in data.columns:
            data["case_number"] = data["case_number"].astype(int)

        if "served_duration" in data.columns:
            data["served_duration"] = data["served_duration"].str.extract(r"(\d+)").fillna(0).astype(int)

        if "bailable" in data.columns:
            data["bailable"] = data["bailable"].map({"Yes": True, "No": False})

        return data

    except Exception as e:
        print(f"Error loading data: {e}")
        return None

# Function to add texts with embeddings to the database
def add_texts_with_embeddings(data):
    texts = data["offense_type"].astype(str).tolist()
    metadatas = data.to_dict(orient="records")

    embeddings_list = embeddings.embed_documents(texts)
    for doc_text, metadata, embedding in zip(texts, metadatas, embeddings_list):
        try:
            case_number = int(metadata.get("case_number", -1))

            print(f"Processing case_number: {case_number}, Metadata: {metadata}")

            # Check if the entry already exists
            existing_entry = session.execute(
                text("SELECT 1 FROM bail_cases WHERE case_number = :case_number"),
                {"case_number": case_number},
            ).fetchone()

            if existing_entry:
                print(f"Skipping duplicate case_number: {case_number}")
                continue

            # Add vector to the vectorstore
            vectorstore.add_vector(
                embedding=embedding,
                metadata={
                    "prisoner_name": metadata.get("prisoner_name"),
                    "case_number": case_number,
                    "charges": metadata.get("charges"),
                    "arrest_date": metadata.get("arrest_date"),
                    "offense_type": metadata.get("offense_type"),
                    "served_duration": metadata.get("served_duration"),
                    "risk_evaluation": metadata.get("risk_evaluation"),
                    "bailable": metadata.get("bailable"),
                    "bail_eligibility": metadata.get("bail_eligibility"),
                    "section": metadata.get("section"),
                    "offense": metadata.get("offense"),
                    "punishment": metadata.get("punishment"),
                }
            )
            print(f"Successfully added case_number: {case_number}")

        except Exception as e:
            print(f"Error for case_number {case_number}: {e}")

if __name__ == "__main__":
    print("Starting main execution...")

    file_path = "/Users/gouthamnaroju/Downloads/Bnsss.csv"
    data = clean_and_load_csv(file_path)

    if data is None:
        print("Error: Data not loaded.")
        exit()

    print("Data loaded successfully.")
    print(f"Data Preview: {data.head()}")

    print("Adding data with embeddings to the database...")
    add_texts_with_embeddings(data)
    print("Database population completed.")
